import Avatar from './Avatar';

Avatar.install = function install(Vue) {
  Vue.component(Avatar.name, Avatar);
};

export default Avatar;
