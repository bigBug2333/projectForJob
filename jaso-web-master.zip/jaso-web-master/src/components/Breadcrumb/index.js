import Breadcrumb from './Breadcrumb';

Breadcrumb.install = function install(Vue) {
  Vue.component(Breadcrumb.name, Breadcrumb);
};

export default Breadcrumb;
