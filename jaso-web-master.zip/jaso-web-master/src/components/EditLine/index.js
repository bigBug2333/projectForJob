import EditLine from './EditLine';

EditLine.install = function install(Vue) {
  Vue.component(EditLine.name, EditLine);
};

export default EditLine;
