import EmptyCard from './EmptyCard';

EmptyCard.install = function install(Vue) {
  Vue.component(EmptyCard.name, EmptyCard);
};

export default EmptyCard;
