import ZoomingImg from './ZoomingImg';

ZoomingImg.install = function install(Vue) {
  Vue.component(ZoomingImg.name, ZoomingImg);
};

export default ZoomingImg;
