<template>
  <div>
    About
  </div>
</template>

<script>
export default {
  name: 'About',
  data() {
    return {
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
</style>
