<template>
  <div>
    Standard
  </div>
</template>

<script>
export default {
  name: 'Standard',
  data() {
    return {
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
</style>
